# AI Burp Payload Assistant Backend

Minimal FastAPI backend for the Burp Suite extension MVP.

## Run

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:GEMINI_API_KEY = "your-api-key-here"
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

If your Windows Python launcher is available as `py`, use:

```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
py -3.11 -m pip install -r requirements.txt
$env:GEMINI_API_KEY = "your-api-key-here"
py -3.11 -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## Health Check

```powershell
Invoke-RestMethod http://127.0.0.1:8000/health
```

## Suggest Payloads

```powershell
$body = @{
  method = "GET"
  url = "https://example.test/search?q=test"
  headers = @{
    "Content-Type" = "text/html"
  }
  selected_text = "q=test"
  parameter_name = "q"
  content_type = "text/html"
} | ConvertTo-Json

Invoke-RestMethod `
  -Method Post `
  -Uri http://127.0.0.1:8000/suggest `
  -ContentType "application/json" `
  -Body $body
```
