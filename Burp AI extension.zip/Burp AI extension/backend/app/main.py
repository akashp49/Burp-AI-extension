from fastapi import FastAPI

from app.api.suggest import router as suggest_router


app = FastAPI(
    title="AI Burp Payload Assistant API",
    version="0.1.0",
    description="Backend API for manual AI-assisted Burp Suite payload suggestions.",
)

app.include_router(suggest_router)


@app.get("/health")
def health_check() -> dict[str, str]:
    return {"status": "ok"}
