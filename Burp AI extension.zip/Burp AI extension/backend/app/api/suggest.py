import json

from fastapi import APIRouter, HTTPException

from app.analysis.analyzer import SecurityContextAnalyzer
from app.core.config import get_settings
from app.core.logging import get_logger
from app.models.analysis import (
    CspInfo,
    ReflectionContext,
    ReflectionEncoding,
    SecurityContext,
    WafVendor,
)
from app.models.suggestions import RequestContext, SuggestResponse
from app.services.gemini_client import (
    GeminiClient,
    GeminiClientError,
    GeminiConfigurationError,
)
from app.services.payload_cache import PayloadCache, build_payload_cache_key
from app.services.prompt_builder import build_context_aware_xss_prompt
from app.services.suggestion_response_parser import parse_suggestion_response


router = APIRouter()
logger = get_logger(__name__)
payload_cache = PayloadCache()


@router.post("/suggest", response_model=SuggestResponse)
async def suggest_payloads(request_context: RequestContext) -> SuggestResponse:
    security_context = _build_security_context(request_context)
    cache_key = build_payload_cache_key(request_context.url, security_context)
    cached_response = payload_cache.get(cache_key)
    if cached_response:
        logger.info("Payload cache hit for key=%s", cache_key[:12])
        return cached_response

    prompt = build_context_aware_xss_prompt(security_context)
    gemini_client = GeminiClient(get_settings())

    try:
        raw_response = await gemini_client.generate_json(prompt)
        parsed_response = parse_suggestion_response(raw_response)
        response = SuggestResponse.model_validate(parsed_response)
        payload_cache.set(cache_key, response)
        logger.info("Payload cache stored key=%s", cache_key[:12])
        return response
    except GeminiConfigurationError as error:
        raise HTTPException(
            status_code=500,
            detail="Gemini API key is not configured",
        ) from error
    except GeminiClientError as error:
        raise HTTPException(
            status_code=502,
            detail=str(error),
        ) from error
    except json.JSONDecodeError as error:
        logger.exception(
            "Gemini returned invalid JSON. Raw response preview=%r",
            _summarize_text(raw_response if 'raw_response' in locals() else ''),
        )
        raise HTTPException(
            status_code=502,
            detail="Gemini returned invalid JSON. See backend logs.",
        ) from error
    except ValueError as error:
        logger.exception(
            "Gemini JSON did not match schema. Raw response preview=%r",
            _summarize_text(raw_response if 'raw_response' in locals() else ''),
        )
        raise HTTPException(
            status_code=502,
            detail="Gemini JSON did not match the expected schema. See backend logs.",
        ) from error


def _summarize_text(value: str) -> str:
    compact_value = " ".join(value.split())

    if len(compact_value) <= 500:
        return compact_value

    return compact_value[:500] + "..."


def _build_security_context(request_context: RequestContext) -> SecurityContext:
    if not request_context.response_body:
        return SecurityContext(
            reflection=False,
            reflection_count=0,
            context=ReflectionContext.UNKNOWN,
            encoding=ReflectionEncoding.UNKNOWN,
            waf=WafVendor.UNKNOWN,
            csp=CspInfo(present=False),
        )

    return SecurityContextAnalyzer().analyze(
        response_body=request_context.response_body,
        response_headers=request_context.response_headers,
        marker=request_context.reflection_marker,
    )
