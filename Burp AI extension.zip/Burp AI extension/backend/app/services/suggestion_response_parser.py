import json
import re

from app.services.json_extractor import extract_json_object


def parse_suggestion_response(raw_response: str) -> dict:
    extracted_response = extract_json_object(raw_response)
    decode_errors: list[Exception] = []

    for candidate in _response_candidates(extracted_response):
        try:
            return _load_json_object(candidate)
        except (json.JSONDecodeError, ValueError) as error:
            decode_errors.append(error)

    recovered_response = _recover_escaped_payloads(extracted_response)
    if recovered_response["payloads"]:
        return recovered_response

    partial_response = _recover_complete_payload_objects(extracted_response)
    if partial_response["payloads"]:
        return partial_response

    raise json.JSONDecodeError(
        f"Could not decode Gemini JSON after {len(decode_errors)} attempts",
        extracted_response,
        0,
    )


def _load_json_object(value: str) -> dict:
    parsed_value = json.loads(value)

    if isinstance(parsed_value, str):
        parsed_value = json.loads(parsed_value)

    if not isinstance(parsed_value, dict):
        raise ValueError("Gemini JSON response must be an object")

    return parsed_value


def _unescape_json_text(value: str) -> str:
    return value.replace('\\"', '"').replace("\\\\", "\\")


def _response_candidates(value: str) -> list[str]:
    unescaped_once = _unescape_json_text(value)
    unescaped_twice = _unescape_json_text(unescaped_once)

    return [
        value,
        unescaped_once,
        extract_json_object(unescaped_once),
        unescaped_twice,
        extract_json_object(unescaped_twice),
    ]


def _recover_escaped_payloads(value: str) -> dict:
    payloads = []
    normalized_value = value.replace("\\\\", "\\")
    item_pattern = re.compile(
        r'(?:payloads\\":\\[\{\\")?payload\\":\\"(?P<payload>.*?)\\",\\"reason\\":\\"'
        r'(?P<reason>.*?)\\",\\"confidence\\":(?P<confidence>[0-9.]+)',
    )

    for match in item_pattern.finditer(normalized_value):
        payloads.append(
            {
                "payload": _decode_escaped_text(match.group("payload")),
                "reason": _decode_escaped_text(match.group("reason")),
                "confidence": float(match.group("confidence")),
            }
        )

    return {"payloads": payloads}


def _decode_escaped_text(value: str) -> str:
    return value.replace('\\"', '"').replace("\\/", "/").replace("\\\\", "\\")


def _recover_complete_payload_objects(value: str) -> dict:
    payloads = []
    item_pattern = re.compile(
        r'"payload"\s*:\s*"(?P<payload>(?:\\.|[^"\\])*)"\s*,\s*'
        r'"reason"\s*:\s*"(?P<reason>(?:\\.|[^"\\])*)"\s*,\s*'
        r'"confidence"\s*:\s*(?P<confidence>[0-9.]+)',
    )

    for match in item_pattern.finditer(value):
        payloads.append(
            {
                "payload": _decode_json_string_fragment(match.group("payload")),
                "reason": _decode_json_string_fragment(match.group("reason")),
                "confidence": float(match.group("confidence")),
            }
        )

    return {"payloads": payloads}


def _decode_json_string_fragment(value: str) -> str:
    return json.loads(f'"{value}"')
