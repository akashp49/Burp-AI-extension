from typing import Any

import httpx

from app.core.logging import get_logger
from app.core.config import Settings


logger = get_logger(__name__)


class GeminiConfigurationError(Exception):
    pass


class GeminiClientError(Exception):
    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class GeminiClient:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    async def generate_json(self, prompt: str) -> str:
        if not self.settings.gemini_api_key:
            raise GeminiConfigurationError("GEMINI_API_KEY is not set")

        url = (
            f"{self.settings.gemini_api_base_url}/models/"
            f"{self.settings.gemini_model}:generateContent"
        )
        request_body = self._build_request_body(prompt)

        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.post(
                url,
                params={"key": self.settings.gemini_api_key},
                json=request_body,
            )

        if response.status_code >= 400:
            raise GeminiClientError(
                f"Gemini API returned HTTP {response.status_code}: "
                f"{self._summarize_response_body(response.text)}",
                status_code=response.status_code,
            )

        response_json = response.json()
        self._log_usage_metadata(response_json)
        return self._extract_text(response_json)

    def _build_request_body(self, prompt: str) -> dict[str, Any]:
        return {
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": prompt}],
                }
            ],
            "generationConfig": {
                "temperature": 0.1,
                "maxOutputTokens": 512,
                "responseMimeType": "application/json",
                "thinkingConfig": {
                    "thinkingBudget": 0,
                },
                "responseSchema": {
                    "type": "OBJECT",
                    "properties": {
                        "payloads": {
                            "type": "ARRAY",
                            "maxItems": 3,
                            "items": {
                                "type": "OBJECT",
                                "properties": {
                                    "payload": {"type": "STRING"},
                                    "reason": {"type": "STRING"},
                                    "confidence": {"type": "NUMBER"},
                                },
                                "required": [
                                    "payload",
                                    "reason",
                                    "confidence",
                                ],
                                "propertyOrdering": [
                                    "payload",
                                    "reason",
                                    "confidence",
                                ],
                            },
                        },
                    },
                    "required": ["payloads"],
                    "propertyOrdering": ["payloads"],
                },
            },
            "safetySettings": [
                {
                    "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                    "threshold": "BLOCK_NONE",
                }
            ],
        }

    def _extract_text(self, response_json: dict[str, Any]) -> str:
        try:
            parts = response_json["candidates"][0]["content"]["parts"]
            text = "".join(
                part.get("text", "")
                for part in parts
                if isinstance(part, dict)
            )
        except (KeyError, IndexError, TypeError) as error:
            raise GeminiClientError(
                "Gemini API response did not contain text: "
                f"{self._summarize_response_body(str(response_json))}"
            ) from error

        if not text.strip():
            raise GeminiClientError(
                "Gemini API returned empty text: "
                f"{self._summarize_response_body(str(response_json))}"
            )

        return text

    def _summarize_response_body(self, response_body: str) -> str:
        compact_body = " ".join(response_body.split())

        if len(compact_body) <= 500:
            return compact_body

        return compact_body[:500] + "..."

    def _log_usage_metadata(self, response_json: dict[str, Any]) -> None:
        usage_metadata = response_json.get("usageMetadata", {})

        if not usage_metadata:
            logger.info("Gemini token usage metadata was not returned")
            return

        logger.info(
            "Gemini token usage: prompt=%s output=%s thoughts=%s total=%s",
            usage_metadata.get("promptTokenCount", 0),
            usage_metadata.get("candidatesTokenCount", 0),
            usage_metadata.get("thoughtsTokenCount", 0),
            usage_metadata.get("totalTokenCount", 0),
        )
