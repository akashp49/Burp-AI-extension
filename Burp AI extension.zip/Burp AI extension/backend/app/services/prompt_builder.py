import json

from app.models.analysis import SecurityContext
from app.services.payload_strategy import build_payload_strategy_hints


def build_context_aware_xss_prompt(security_context: SecurityContext) -> str:
    compact_context = {
        "r": security_context.reflection,
        "ctx": security_context.context.value,
        "enc": security_context.encoding.value,
        "waf": security_context.waf.value,
        "csp_inline": security_context.csp.unsafe_inline,
        "nonce": security_context.csp.nonce_present,
        "strict_dynamic": security_context.csp.strict_dynamic,
        "h": build_payload_strategy_hints(security_context),
    }

    return (
        "Generate 3 advanced reflected XSS payload mutations using h. "
        "JSON only. reason<=6 words. "
        f"{json.dumps(compact_context, separators=(',', ':'))}"
    )
