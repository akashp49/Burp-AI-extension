from app.models.analysis import (
    ReflectionContext,
    ReflectionEncoding,
    SecurityContext,
    WafVendor,
)


def build_payload_strategy_hints(security_context: SecurityContext) -> list[str]:
    hints: list[str] = []

    hints.extend(_context_hints(security_context.context))
    hints.extend(_encoding_hints(security_context.encoding))
    hints.extend(_waf_hints(security_context.waf))
    hints.extend(_csp_hints(security_context))

    return _deduplicate(hints)[:5]


def _context_hints(context: ReflectionContext) -> list[str]:
    if context == ReflectionContext.HTML_ATTRIBUTE:
        return ["attr_breakout", "event_handler"]

    if context == ReflectionContext.JS_STRING:
        return ["js_string_breakout", "quote_escape"]

    if context == ReflectionContext.SCRIPT_BLOCK:
        return ["script_breakout", "js_exec"]

    if context == ReflectionContext.URL_CONTEXT:
        return ["url_breakout", "encoded_vector"]

    if context == ReflectionContext.JSON_CONTEXT:
        return ["json_string_breakout", "quote_escape"]

    if context == ReflectionContext.HTML_BODY:
        return ["tag_injection", "event_handler"]

    return ["generic_reflected_xss"]


def _encoding_hints(encoding: ReflectionEncoding) -> list[str]:
    if encoding == ReflectionEncoding.HTML_ENTITY:
        return ["html_entity_safe"]

    if encoding == ReflectionEncoding.URL_ENCODING:
        return ["url_encoded"]

    if encoding == ReflectionEncoding.UNICODE_ESCAPE:
        return ["unicode_escape"]

    if encoding == ReflectionEncoding.PARTIAL_ESCAPE:
        return ["partial_escape_bypass"]

    return []


def _waf_hints(waf: WafVendor) -> list[str]:
    if waf == WafVendor.UNKNOWN:
        return []

    return [f"{waf.value}_bypass"]


def _csp_hints(security_context: SecurityContext) -> list[str]:
    if not security_context.csp.present:
        return []

    hints = []

    if not security_context.csp.unsafe_inline:
        hints.append("csp_no_inline")

    if security_context.csp.nonce_present:
        hints.append("nonce_aware")

    if security_context.csp.strict_dynamic:
        hints.append("strict_dynamic_aware")

    return hints


def _deduplicate(values: list[str]) -> list[str]:
    seen = set()
    result = []

    for value in values:
        if value in seen:
            continue

        seen.add(value)
        result.append(value)

    return result
