def extract_json_object(text: str) -> str:
    cleaned_text = text.strip()

    if cleaned_text.startswith("```"):
        cleaned_text = _strip_markdown_fence(cleaned_text)

    start = cleaned_text.find("{")
    end = cleaned_text.rfind("}")

    if start == -1 or end == -1 or start >= end:
        return cleaned_text

    return cleaned_text[start:end + 1]


def _strip_markdown_fence(text: str) -> str:
    lines = text.splitlines()

    if lines and lines[0].startswith("```"):
        lines = lines[1:]

    if lines and lines[-1].startswith("```"):
        lines = lines[:-1]

    return "\n".join(lines).strip()

