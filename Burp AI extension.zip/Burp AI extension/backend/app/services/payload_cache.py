import hashlib
import json
from urllib.parse import urlparse

from app.models.analysis import SecurityContext
from app.models.suggestions import SuggestResponse


class PayloadCache:
    def __init__(self) -> None:
        self._items: dict[str, SuggestResponse] = {}

    def get(self, cache_key: str) -> SuggestResponse | None:
        return self._items.get(cache_key)

    def set(self, cache_key: str, response: SuggestResponse) -> None:
        self._items[cache_key] = response

    def clear(self) -> None:
        self._items.clear()


def build_payload_cache_key(url: str, security_context: SecurityContext) -> str:
    key_material = {
        "hostname": urlparse(url).hostname or "",
        "context": security_context.context.value,
        "encoding": security_context.encoding.value,
        "waf": security_context.waf.value,
    }
    serialized_key_material = json.dumps(
        key_material,
        sort_keys=True,
        separators=(",", ":"),
    )

    return hashlib.sha256(serialized_key_material.encode("utf-8")).hexdigest()

