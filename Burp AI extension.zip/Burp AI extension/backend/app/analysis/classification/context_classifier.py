from html.parser import HTMLParser

from app.models.analysis import (
    ReflectionContext,
    ReflectionContextResult,
    ReflectionPosition,
)


URL_ATTRIBUTES = {
    "action",
    "formaction",
    "href",
    "poster",
    "src",
    "srcset",
}


class ReflectionContextClassifier:
    def classify(self, position: ReflectionPosition) -> ReflectionContextResult:
        snippet = position.before + position.reflected_value + position.after
        marker_index = len(position.before)

        html_attribute = _find_html_attribute_context(snippet, position.reflected_value)
        if html_attribute:
            attribute_name = html_attribute.lower()
            context = (
                ReflectionContext.URL_CONTEXT
                if attribute_name in URL_ATTRIBUTES
                else ReflectionContext.HTML_ATTRIBUTE
            )
            return ReflectionContextResult(
                marker=position.marker,
                context=context,
                evidence=f"marker appears in HTML attribute '{attribute_name}'",
            )

        if _looks_like_script_context(position.before, position.after):
            if _looks_like_js_string(position.before, marker_index):
                return ReflectionContextResult(
                    marker=position.marker,
                    context=ReflectionContext.JS_STRING,
                    evidence="marker appears inside quoted JavaScript string",
                )

            return ReflectionContextResult(
                marker=position.marker,
                context=ReflectionContext.SCRIPT_BLOCK,
                evidence="marker appears inside script block",
            )

        if _looks_like_json_context(position.before, position.after):
            return ReflectionContextResult(
                marker=position.marker,
                context=ReflectionContext.JSON_CONTEXT,
                evidence="marker appears inside JSON string value",
            )

        if _looks_like_url_context(position.before, position.after):
            return ReflectionContextResult(
                marker=position.marker,
                context=ReflectionContext.URL_CONTEXT,
                evidence="marker appears inside URL-like value",
            )

        if _looks_like_html_body(position.before, position.after):
            return ReflectionContextResult(
                marker=position.marker,
                context=ReflectionContext.HTML_BODY,
                evidence="marker appears between HTML tags",
            )

        return ReflectionContextResult(
            marker=position.marker,
            context=ReflectionContext.UNKNOWN,
            evidence="no deterministic context match",
        )


class _AttributeMarkerParser(HTMLParser):
    def __init__(self, marker: str) -> None:
        super().__init__(convert_charrefs=False)
        self.marker = marker
        self.attribute_name: str | None = None

    def handle_starttag(
            self,
            tag: str,
            attrs: list[tuple[str, str | None]]) -> None:
        for name, value in attrs:
            if value and self.marker in value:
                self.attribute_name = name

    def handle_startendtag(
            self,
            tag: str,
            attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)


def _find_html_attribute_context(snippet: str, marker: str) -> str | None:
    parser = _AttributeMarkerParser(marker)
    parser.feed(snippet)

    if parser.attribute_name:
        return parser.attribute_name

    return _find_partial_attribute_name(snippet, marker)


def _find_partial_attribute_name(snippet: str, marker: str) -> str | None:
    marker_index = snippet.find(marker)
    tag_start = snippet.rfind("<", 0, marker_index)
    tag_end = snippet.rfind(">", 0, marker_index)

    if tag_start == -1 or tag_end > tag_start:
        return None

    equals_index = snippet.rfind("=", tag_start, marker_index)
    if equals_index == -1:
        return None

    name_end = equals_index
    name_start = name_end - 1
    while name_start >= tag_start and _is_attribute_name_char(snippet[name_start]):
        name_start -= 1

    attribute_name = snippet[name_start + 1:name_end].strip().lower()
    return attribute_name or None


def _is_attribute_name_char(character: str) -> bool:
    return character.isalnum() or character in {"-", "_", ":"}


def _looks_like_script_context(before: str, after: str) -> bool:
    lower_before = before.lower()
    lower_after = after.lower()
    return lower_before.rfind("<script") > lower_before.rfind("</script") and (
        "</script" in lower_after or "<script" in lower_before
    )


def _looks_like_js_string(before: str, marker_index: int) -> bool:
    del marker_index
    quote = _active_unescaped_quote(before)
    return quote in {'"', "'", "`"}


def _active_unescaped_quote(value: str) -> str | None:
    active_quote: str | None = None
    escaped = False

    for character in value:
        if escaped:
            escaped = False
            continue

        if character == "\\":
            escaped = True
            continue

        if active_quote:
            if character == active_quote:
                active_quote = None
            continue

        if character in {'"', "'", "`"}:
            active_quote = character

    return active_quote


def _looks_like_json_context(before: str, after: str) -> bool:
    stripped_before = before.rstrip()
    stripped_after = after.lstrip()

    if not stripped_after.startswith('"'):
        return False

    previous_quote = stripped_before.rfind('"')
    previous_colon = stripped_before.rfind(":")
    previous_comma = stripped_before.rfind(",")
    previous_open = max(stripped_before.rfind("{"), stripped_before.rfind("["))

    return previous_colon > max(previous_comma, previous_open) and (
        previous_quote > previous_colon
    )


def _looks_like_url_context(before: str, after: str) -> bool:
    nearby = (before[-20:] + after[:20]).lower()
    return any(prefix in nearby for prefix in ("http://", "https://", "//", "?"))


def _looks_like_html_body(before: str, after: str) -> bool:
    return ">" in before and "<" in after

