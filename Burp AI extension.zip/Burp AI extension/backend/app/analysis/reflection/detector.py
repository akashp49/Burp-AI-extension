from app.models.analysis import ReflectionDetectionResult


class ReflectionDetector:
    def detect(self, response_body: str, marker: str) -> ReflectionDetectionResult:
        if not marker:
            raise ValueError("marker must not be empty")

        offsets = self._find_offsets(response_body, marker)

        return ReflectionDetectionResult(
            marker=marker,
            reflected=bool(offsets),
            occurrence_count=len(offsets),
            offsets=offsets,
        )

    def _find_offsets(self, response_body: str, marker: str) -> list[int]:
        offsets: list[int] = []
        search_from = 0

        while True:
            offset = response_body.find(marker, search_from)
            if offset == -1:
                return offsets

            offsets.append(offset)
            search_from = offset + len(marker)

