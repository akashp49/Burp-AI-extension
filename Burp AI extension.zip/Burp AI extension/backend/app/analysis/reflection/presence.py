from app.analysis.reflection.detector import ReflectionDetector
from app.models.analysis import ReflectionPresenceResult


class ReflectionPresenceChecker:
    def __init__(self, detector: ReflectionDetector | None = None) -> None:
        self.detector = detector or ReflectionDetector()

    def check(self, response_body: str, marker: str) -> ReflectionPresenceResult:
        detection_result = self.detector.detect(response_body, marker)

        return ReflectionPresenceResult(
            marker=detection_result.marker,
            reflected=detection_result.reflected,
            occurrence_count=detection_result.occurrence_count,
        )

