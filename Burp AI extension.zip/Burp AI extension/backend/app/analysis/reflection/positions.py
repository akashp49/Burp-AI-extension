from app.analysis.reflection.detector import ReflectionDetector
from app.models.analysis import ReflectionPosition, ReflectionPositionResult


class ReflectionPositionMapper:
    def __init__(
            self,
            detector: ReflectionDetector | None = None,
            context_window: int = 40) -> None:
        if context_window < 0:
            raise ValueError("context_window must be zero or greater")

        self.detector = detector or ReflectionDetector()
        self.context_window = context_window

    def map_positions(
            self,
            response_body: str,
            marker: str) -> ReflectionPositionResult:
        detection_result = self.detector.detect(response_body, marker)
        positions = [
            self._build_position(response_body, marker, offset)
            for offset in detection_result.offsets
        ]

        return ReflectionPositionResult(
            marker=marker,
            reflected=detection_result.reflected,
            positions=positions,
        )

    def _build_position(
            self,
            response_body: str,
            marker: str,
            offset: int) -> ReflectionPosition:
        marker_end = offset + len(marker)
        before_start = max(0, offset - self.context_window)
        after_end = min(len(response_body), marker_end + self.context_window)

        return ReflectionPosition(
            marker=marker,
            offset=offset,
            before=response_body[before_start:offset],
            reflected_value=response_body[offset:marker_end],
            after=response_body[marker_end:after_end],
        )

