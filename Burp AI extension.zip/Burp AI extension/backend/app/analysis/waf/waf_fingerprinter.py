from app.models.analysis import WafFingerprintResult, WafVendor


class WafFingerprinter:
    def fingerprint(self, headers: dict[str, str]) -> WafFingerprintResult:
        normalized_headers = _normalize_headers(headers)
        evidence = _collect_evidence(normalized_headers)

        for vendor in (
                WafVendor.CLOUDFLARE,
                WafVendor.AKAMAI,
                WafVendor.IMPERVA,
                WafVendor.AWS_WAF,
        ):
            vendor_evidence = [
                item for item in evidence if item.startswith(f"{vendor.value}:")
            ]
            if vendor_evidence:
                return WafFingerprintResult(
                    vendor=vendor,
                    evidence=vendor_evidence,
                )

        return WafFingerprintResult(vendor=WafVendor.UNKNOWN, evidence=[])


def _normalize_headers(headers: dict[str, str]) -> dict[str, str]:
    return {name.lower(): value.lower() for name, value in headers.items()}


def _collect_evidence(headers: dict[str, str]) -> list[str]:
    evidence: list[str] = []
    cookie_header = headers.get("set-cookie", "")
    server_header = headers.get("server", "")

    if "cf-ray" in headers:
        evidence.append("cloudflare: cf-ray header")
    if "__cf_bm" in cookie_header or "cf_clearance" in cookie_header:
        evidence.append("cloudflare: cloudflare cookie")
    if "cloudflare" in server_header:
        evidence.append("cloudflare: server header")

    if "akamai" in server_header:
        evidence.append("akamai: server header")
    if "akamai" in headers.get("x-cache", ""):
        evidence.append("akamai: x-cache header")
    if "ak_bmsc" in cookie_header or "bm_sv" in cookie_header:
        evidence.append("akamai: akamai bot manager cookie")

    if "incap_ses" in cookie_header or "visid_incap" in cookie_header:
        evidence.append("imperva: imperva cookie")
    if "incapsula" in server_header or "imperva" in server_header:
        evidence.append("imperva: server header")
    if "x-iinfo" in headers:
        evidence.append("imperva: x-iinfo header")

    if "x-amzn-waf-action" in headers:
        evidence.append("aws_waf: x-amzn-waf-action header")
    if "awsalb" in cookie_header or "aws-waf-token" in cookie_header:
        evidence.append("aws_waf: aws waf cookie")

    return evidence

