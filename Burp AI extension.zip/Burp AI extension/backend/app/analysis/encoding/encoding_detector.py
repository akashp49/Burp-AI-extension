import html
from urllib.parse import quote

from app.models.analysis import EncodingDetectionResult, ReflectionEncoding


class EncodingDetector:
    def detect(self, response_text: str, marker: str) -> EncodingDetectionResult:
        if not marker:
            raise ValueError("marker must not be empty")

        if marker in response_text:
            return EncodingDetectionResult(
                marker=marker,
                encoding=ReflectionEncoding.NONE,
                evidence="raw marker appears in response",
            )

        html_encoded = html.escape(marker, quote=True)
        if html_encoded != marker and html_encoded in response_text:
            return EncodingDetectionResult(
                marker=marker,
                encoding=ReflectionEncoding.HTML_ENTITY,
                evidence="HTML entity encoded marker appears in response",
            )

        url_encoded = quote(marker, safe="")
        if url_encoded != marker and url_encoded in response_text:
            return EncodingDetectionResult(
                marker=marker,
                encoding=ReflectionEncoding.URL_ENCODING,
                evidence="URL encoded marker appears in response",
            )

        unicode_escaped = _unicode_escape(marker)
        if unicode_escaped != marker and unicode_escaped in response_text:
            return EncodingDetectionResult(
                marker=marker,
                encoding=ReflectionEncoding.UNICODE_ESCAPE,
                evidence="Unicode escaped marker appears in response",
            )

        if _looks_partially_escaped(response_text, marker):
            return EncodingDetectionResult(
                marker=marker,
                encoding=ReflectionEncoding.PARTIAL_ESCAPE,
                evidence="some marker characters survived or were escaped",
            )

        return EncodingDetectionResult(
            marker=marker,
            encoding=ReflectionEncoding.UNKNOWN,
            evidence="no deterministic encoding match",
        )


def _unicode_escape(value: str) -> str:
    return "".join(f"\\u{ord(character):04x}" for character in value)


def _looks_partially_escaped(response_text: str, marker: str) -> bool:
    if len(marker) < 3:
        return False

    marker_characters = set(marker)
    surviving_characters = sum(
        1 for character in marker_characters if character in response_text
    )
    escaped_signals = ("&lt;", "&gt;", "&#", "%", "\\u", "\\x")

    return surviving_characters >= max(2, len(marker_characters) // 2) and any(
        signal in response_text for signal in escaped_signals
    )

