from app.analysis.classification.context_classifier import ReflectionContextClassifier
from app.analysis.csp.csp_extractor import CspExtractor
from app.analysis.encoding.encoding_detector import EncodingDetector
from app.analysis.reflection.positions import ReflectionPositionMapper
from app.analysis.waf.waf_fingerprinter import WafFingerprinter
from app.models.analysis import (
    ReflectionContext,
    ReflectionEncoding,
    SecurityContext,
)


class SecurityContextAnalyzer:
    def __init__(
            self,
            position_mapper: ReflectionPositionMapper | None = None,
            context_classifier: ReflectionContextClassifier | None = None,
            encoding_detector: EncodingDetector | None = None,
            csp_extractor: CspExtractor | None = None,
            waf_fingerprinter: WafFingerprinter | None = None) -> None:
        self.position_mapper = position_mapper or ReflectionPositionMapper()
        self.context_classifier = context_classifier or ReflectionContextClassifier()
        self.encoding_detector = encoding_detector or EncodingDetector()
        self.csp_extractor = csp_extractor or CspExtractor()
        self.waf_fingerprinter = waf_fingerprinter or WafFingerprinter()

    def analyze(
            self,
            response_body: str,
            response_headers: dict[str, str],
            marker: str) -> SecurityContext:
        position_result = self.position_mapper.map_positions(response_body, marker)
        csp_info = self.csp_extractor.extract(response_headers)
        waf_result = self.waf_fingerprinter.fingerprint(response_headers)

        if not position_result.reflected:
            return SecurityContext(
                reflection=False,
                reflection_count=0,
                context=ReflectionContext.UNKNOWN,
                encoding=ReflectionEncoding.UNKNOWN,
                waf=waf_result.vendor,
                csp=csp_info,
            )

        primary_position = position_result.positions[0]
        context_result = self.context_classifier.classify(primary_position)
        encoding_result = self.encoding_detector.detect(
            primary_position.reflected_value,
            marker,
        )

        return SecurityContext(
            reflection=True,
            reflection_count=len(position_result.positions),
            context=context_result.context,
            encoding=encoding_result.encoding,
            waf=waf_result.vendor,
            csp=csp_info,
        )

