from app.models.analysis import CspInfo


class CspExtractor:
    def extract(self, headers: dict[str, str]) -> CspInfo:
        policy = _get_header(headers, "content-security-policy")

        if not policy:
            return CspInfo(present=False)

        directives = _parse_directives(policy)
        script_src = directives.get("script-src") or directives.get("default-src") or []

        return CspInfo(
            present=True,
            unsafe_inline="'unsafe-inline'" in script_src,
            nonce_present=any(value.startswith("'nonce-") for value in script_src),
            strict_dynamic="'strict-dynamic'" in script_src,
            script_src=script_src,
            raw_policy=policy,
        )


def _get_header(headers: dict[str, str], header_name: str) -> str | None:
    for name, value in headers.items():
        if name.lower() == header_name:
            return value

    return None


def _parse_directives(policy: str) -> dict[str, list[str]]:
    directives: dict[str, list[str]] = {}

    for raw_directive in policy.split(";"):
        parts = raw_directive.strip().split()
        if not parts:
            continue

        directive_name = parts[0].lower()
        directive_values = parts[1:]
        directives[directive_name] = directive_values

    return directives

