from pydantic import BaseModel, Field


class RequestContext(BaseModel):
    method: str = Field(..., min_length=1, max_length=16)
    url: str = Field(..., min_length=1, max_length=2048)
    headers: dict[str, str] = Field(default_factory=dict)
    body: str | None = Field(default=None, max_length=20000)
    selected_text: str | None = Field(default=None, max_length=4000)
    parameter_name: str | None = Field(default=None, max_length=200)
    content_type: str | None = Field(default=None, max_length=200)
    response_headers: dict[str, str] = Field(default_factory=dict)
    response_body: str | None = Field(default=None, max_length=50000)
    reflection_marker: str = Field(default="XAIREF123", min_length=1, max_length=100)


class PayloadSuggestion(BaseModel):
    payload: str = Field(..., min_length=1, max_length=1000)
    reason: str = Field(..., min_length=1, max_length=500)
    confidence: float = Field(..., ge=0.0, le=1.0)


class SuggestResponse(BaseModel):
    payloads: list[PayloadSuggestion] = Field(default_factory=list, max_length=10)
