from enum import StrEnum

from pydantic import BaseModel, Field


class ReflectionDetectionResult(BaseModel):
    marker: str = Field(..., min_length=1)
    reflected: bool
    occurrence_count: int = Field(..., ge=0)
    offsets: list[int] = Field(default_factory=list)


class ReflectionPresenceResult(BaseModel):
    marker: str = Field(..., min_length=1)
    reflected: bool
    occurrence_count: int = Field(..., ge=0)


class ReflectionPosition(BaseModel):
    marker: str = Field(..., min_length=1)
    offset: int = Field(..., ge=0)
    before: str
    reflected_value: str
    after: str


class ReflectionPositionResult(BaseModel):
    marker: str = Field(..., min_length=1)
    reflected: bool
    positions: list[ReflectionPosition] = Field(default_factory=list)


class ReflectionContext(StrEnum):
    HTML_BODY = "HTML_BODY"
    HTML_ATTRIBUTE = "HTML_ATTRIBUTE"
    SCRIPT_BLOCK = "SCRIPT_BLOCK"
    JS_STRING = "JS_STRING"
    URL_CONTEXT = "URL_CONTEXT"
    JSON_CONTEXT = "JSON_CONTEXT"
    UNKNOWN = "UNKNOWN"


class ReflectionContextResult(BaseModel):
    marker: str = Field(..., min_length=1)
    context: ReflectionContext
    evidence: str = Field(default="", max_length=200)


class ReflectionEncoding(StrEnum):
    NONE = "NONE"
    HTML_ENTITY = "HTML_ENTITY"
    URL_ENCODING = "URL_ENCODING"
    UNICODE_ESCAPE = "UNICODE_ESCAPE"
    PARTIAL_ESCAPE = "PARTIAL_ESCAPE"
    UNKNOWN = "UNKNOWN"


class EncodingDetectionResult(BaseModel):
    marker: str = Field(..., min_length=1)
    encoding: ReflectionEncoding
    evidence: str = Field(default="", max_length=200)


class CspInfo(BaseModel):
    present: bool
    unsafe_inline: bool = False
    nonce_present: bool = False
    strict_dynamic: bool = False
    script_src: list[str] = Field(default_factory=list)
    raw_policy: str | None = Field(default=None, max_length=4000)


class WafVendor(StrEnum):
    CLOUDFLARE = "cloudflare"
    AKAMAI = "akamai"
    IMPERVA = "imperva"
    AWS_WAF = "aws_waf"
    UNKNOWN = "unknown"


class WafFingerprintResult(BaseModel):
    vendor: WafVendor
    evidence: list[str] = Field(default_factory=list)


class SecurityContext(BaseModel):
    reflection: bool
    reflection_count: int = Field(..., ge=0)
    context: ReflectionContext = ReflectionContext.UNKNOWN
    encoding: ReflectionEncoding = ReflectionEncoding.UNKNOWN
    waf: WafVendor = WafVendor.UNKNOWN
    csp: CspInfo = Field(default_factory=lambda: CspInfo(present=False))
