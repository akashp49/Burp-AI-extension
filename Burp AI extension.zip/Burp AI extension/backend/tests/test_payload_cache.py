import unittest

from app.models.analysis import (
    CspInfo,
    ReflectionContext,
    ReflectionEncoding,
    SecurityContext,
    WafVendor,
)
from app.models.suggestions import PayloadSuggestion, SuggestResponse
from app.services.payload_cache import PayloadCache, build_payload_cache_key


class PayloadCacheTestCase(unittest.TestCase):
    def test_cache_stores_and_returns_response(self) -> None:
        cache = PayloadCache()
        response = SuggestResponse(
            payloads=[
                PayloadSuggestion(
                    payload="<svg/onload=alert(1)>",
                    reason="HTML body",
                    confidence=0.8,
                )
            ]
        )

        cache.set("key", response)

        self.assertEqual(cache.get("key"), response)

    def test_cache_key_uses_hostname_context_encoding_and_waf(self) -> None:
        context = self._context(
            ReflectionContext.HTML_ATTRIBUTE,
            ReflectionEncoding.NONE,
            WafVendor.CLOUDFLARE,
        )

        first_key = build_payload_cache_key(
            "https://example.test/search?q=1",
            context,
        )
        second_key = build_payload_cache_key(
            "https://example.test/profile?id=2",
            context,
        )

        self.assertEqual(first_key, second_key)

    def test_cache_key_changes_when_context_changes(self) -> None:
        first_key = build_payload_cache_key(
            "https://example.test/search",
            self._context(
                ReflectionContext.HTML_ATTRIBUTE,
                ReflectionEncoding.NONE,
                WafVendor.CLOUDFLARE,
            ),
        )
        second_key = build_payload_cache_key(
            "https://example.test/search",
            self._context(
                ReflectionContext.JS_STRING,
                ReflectionEncoding.NONE,
                WafVendor.CLOUDFLARE,
            ),
        )

        self.assertNotEqual(first_key, second_key)

    def _context(
            self,
            context: ReflectionContext,
            encoding: ReflectionEncoding,
            waf: WafVendor) -> SecurityContext:
        return SecurityContext(
            reflection=True,
            reflection_count=1,
            context=context,
            encoding=encoding,
            waf=waf,
            csp=CspInfo(present=False),
        )


if __name__ == "__main__":
    unittest.main()

