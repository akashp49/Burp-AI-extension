import unittest

from app.analysis.classification.context_classifier import ReflectionContextClassifier
from app.models.analysis import ReflectionContext, ReflectionPosition


class ReflectionContextClassifierTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.classifier = ReflectionContextClassifier()

    def test_classifies_html_body_context(self) -> None:
        result = self.classifier.classify(
            self._position("<div>", "</div>")
        )

        self.assertEqual(result.context, ReflectionContext.HTML_BODY)

    def test_classifies_html_attribute_context(self) -> None:
        result = self.classifier.classify(
            self._position('<input value="', '">')
        )

        self.assertEqual(result.context, ReflectionContext.HTML_ATTRIBUTE)

    def test_classifies_url_attribute_context(self) -> None:
        result = self.classifier.classify(
            self._position('<a href="https://example.test/?q=', '">')
        )

        self.assertEqual(result.context, ReflectionContext.URL_CONTEXT)

    def test_classifies_script_block_context(self) -> None:
        result = self.classifier.classify(
            self._position("<script>", "</script>")
        )

        self.assertEqual(result.context, ReflectionContext.SCRIPT_BLOCK)

    def test_classifies_js_string_context(self) -> None:
        result = self.classifier.classify(
            self._position('<script>var x = "', '";</script>')
        )

        self.assertEqual(result.context, ReflectionContext.JS_STRING)

    def test_classifies_json_context(self) -> None:
        result = self.classifier.classify(
            self._position('{"name":"', '"}')
        )

        self.assertEqual(result.context, ReflectionContext.JSON_CONTEXT)

    def _position(self, before: str, after: str) -> ReflectionPosition:
        return ReflectionPosition(
            marker="XAIREF123",
            offset=len(before),
            before=before,
            reflected_value="XAIREF123",
            after=after,
        )


if __name__ == "__main__":
    unittest.main()

