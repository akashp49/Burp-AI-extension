import unittest

from app.analysis.encoding.encoding_detector import EncodingDetector
from app.models.analysis import ReflectionEncoding


class EncodingDetectorTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.detector = EncodingDetector()

    def test_detects_no_encoding(self) -> None:
        result = self.detector.detect("<div>XAIREF123</div>", "XAIREF123")

        self.assertEqual(result.encoding, ReflectionEncoding.NONE)

    def test_detects_html_entity_encoding(self) -> None:
        result = self.detector.detect(
            "&lt;XAIREF123&gt;",
            "<XAIREF123>",
        )

        self.assertEqual(result.encoding, ReflectionEncoding.HTML_ENTITY)

    def test_detects_url_encoding(self) -> None:
        result = self.detector.detect(
            "%3CXAIREF123%3E",
            "<XAIREF123>",
        )

        self.assertEqual(result.encoding, ReflectionEncoding.URL_ENCODING)

    def test_detects_unicode_escaping(self) -> None:
        result = self.detector.detect(
            "\\u0058\\u0041\\u0049\\u0052\\u0045\\u0046\\u0031\\u0032\\u0033",
            "XAIREF123",
        )

        self.assertEqual(result.encoding, ReflectionEncoding.UNICODE_ESCAPE)

    def test_detects_partial_escaping(self) -> None:
        result = self.detector.detect(
            "&lt;XAIREF123",
            "<XAIREF123>",
        )

        self.assertEqual(result.encoding, ReflectionEncoding.PARTIAL_ESCAPE)

    def test_reports_unknown_when_marker_is_absent(self) -> None:
        result = self.detector.detect("no useful reflection", "XAIREF123")

        self.assertEqual(result.encoding, ReflectionEncoding.UNKNOWN)

    def test_rejects_empty_marker(self) -> None:
        with self.assertRaises(ValueError):
            self.detector.detect("anything", "")


if __name__ == "__main__":
    unittest.main()

