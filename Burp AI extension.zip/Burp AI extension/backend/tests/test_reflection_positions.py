import unittest

from app.analysis.reflection.positions import ReflectionPositionMapper


class ReflectionPositionMapperTestCase(unittest.TestCase):
    def test_maps_single_reflection_position(self) -> None:
        mapper = ReflectionPositionMapper(context_window=5)

        result = mapper.map_positions("<div>XAIREF123</div>", "XAIREF123")

        self.assertTrue(result.reflected)
        self.assertEqual(len(result.positions), 1)
        self.assertEqual(result.positions[0].offset, 5)
        self.assertEqual(result.positions[0].before, "<div>")
        self.assertEqual(result.positions[0].reflected_value, "XAIREF123")
        self.assertEqual(result.positions[0].after, "</div")

    def test_maps_multiple_reflection_positions(self) -> None:
        mapper = ReflectionPositionMapper(context_window=3)

        result = mapper.map_positions(
            "<p>XAIREF123</p><span>XAIREF123</span>",
            "XAIREF123",
        )

        self.assertEqual(len(result.positions), 2)
        self.assertEqual(result.positions[0].before, "<p>")
        self.assertEqual(result.positions[1].before, "an>")

    def test_returns_empty_positions_when_not_reflected(self) -> None:
        mapper = ReflectionPositionMapper()

        result = mapper.map_positions("<div>missing</div>", "XAIREF123")

        self.assertFalse(result.reflected)
        self.assertEqual(result.positions, [])

    def test_rejects_negative_context_window(self) -> None:
        with self.assertRaises(ValueError):
            ReflectionPositionMapper(context_window=-1)


if __name__ == "__main__":
    unittest.main()

