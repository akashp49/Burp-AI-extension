import unittest

from app.analysis.csp.csp_extractor import CspExtractor


class CspExtractorTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.extractor = CspExtractor()

    def test_reports_absent_csp(self) -> None:
        result = self.extractor.extract({"Server": "nginx"})

        self.assertFalse(result.present)
        self.assertFalse(result.unsafe_inline)
        self.assertEqual(result.script_src, [])

    def test_extracts_script_src_values(self) -> None:
        result = self.extractor.extract(
            {
                "Content-Security-Policy": (
                    "default-src 'self'; script-src 'self' cdn.example"
                )
            }
        )

        self.assertTrue(result.present)
        self.assertEqual(result.script_src, ["'self'", "cdn.example"])

    def test_detects_unsafe_inline(self) -> None:
        result = self.extractor.extract(
            {"Content-Security-Policy": "script-src 'self' 'unsafe-inline'"}
        )

        self.assertTrue(result.unsafe_inline)

    def test_detects_nonce(self) -> None:
        result = self.extractor.extract(
            {"Content-Security-Policy": "script-src 'nonce-abc123' 'self'"}
        )

        self.assertTrue(result.nonce_present)

    def test_detects_strict_dynamic(self) -> None:
        result = self.extractor.extract(
            {"Content-Security-Policy": "script-src 'strict-dynamic' 'nonce-x'"}
        )

        self.assertTrue(result.strict_dynamic)

    def test_falls_back_to_default_src(self) -> None:
        result = self.extractor.extract(
            {"Content-Security-Policy": "default-src 'self'"}
        )

        self.assertEqual(result.script_src, ["'self'"])

    def test_header_name_is_case_insensitive(self) -> None:
        result = self.extractor.extract(
            {"content-security-policy": "script-src 'self'"}
        )

        self.assertTrue(result.present)


if __name__ == "__main__":
    unittest.main()

