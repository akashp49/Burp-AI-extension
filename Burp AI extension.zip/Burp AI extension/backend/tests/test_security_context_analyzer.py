import unittest

from app.analysis.analyzer import SecurityContextAnalyzer
from app.models.analysis import ReflectionContext, ReflectionEncoding, WafVendor


class SecurityContextAnalyzerTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.analyzer = SecurityContextAnalyzer()

    def test_builds_context_for_reflected_html_attribute(self) -> None:
        context = self.analyzer.analyze(
            response_body='<input value="XAIREF123">',
            response_headers={"CF-Ray": "abc"},
            marker="XAIREF123",
        )

        self.assertTrue(context.reflection)
        self.assertEqual(context.reflection_count, 1)
        self.assertEqual(context.context, ReflectionContext.HTML_ATTRIBUTE)
        self.assertEqual(context.encoding, ReflectionEncoding.NONE)
        self.assertEqual(context.waf, WafVendor.CLOUDFLARE)

    def test_builds_context_when_reflection_absent(self) -> None:
        context = self.analyzer.analyze(
            response_body="<div>not reflected</div>",
            response_headers={},
            marker="XAIREF123",
        )

        self.assertFalse(context.reflection)
        self.assertEqual(context.reflection_count, 0)
        self.assertEqual(context.context, ReflectionContext.UNKNOWN)

    def test_includes_csp_context(self) -> None:
        context = self.analyzer.analyze(
            response_body="<div>XAIREF123</div>",
            response_headers={
                "Content-Security-Policy": "script-src 'nonce-abc' 'strict-dynamic'"
            },
            marker="XAIREF123",
        )

        self.assertTrue(context.csp.present)
        self.assertTrue(context.csp.nonce_present)
        self.assertTrue(context.csp.strict_dynamic)


if __name__ == "__main__":
    unittest.main()

