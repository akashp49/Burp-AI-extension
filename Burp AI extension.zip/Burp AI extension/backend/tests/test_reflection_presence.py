import unittest

from app.analysis.reflection.presence import ReflectionPresenceChecker


class ReflectionPresenceCheckerTestCase(unittest.TestCase):
    def test_reports_reflection_present(self) -> None:
        checker = ReflectionPresenceChecker()

        result = checker.check("<div>XAIREF123</div>", "XAIREF123")

        self.assertTrue(result.reflected)
        self.assertEqual(result.occurrence_count, 1)

    def test_reports_reflection_absent(self) -> None:
        checker = ReflectionPresenceChecker()

        result = checker.check("<div>no reflected marker</div>", "XAIREF123")

        self.assertFalse(result.reflected)
        self.assertEqual(result.occurrence_count, 0)

    def test_hides_offsets_from_presence_result(self) -> None:
        checker = ReflectionPresenceChecker()

        result = checker.check("XAIREF123", "XAIREF123")

        self.assertNotIn("offsets", result.model_dump())


if __name__ == "__main__":
    unittest.main()

