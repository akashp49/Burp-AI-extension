import unittest

from app.analysis.reflection.detector import ReflectionDetector


class ReflectionDetectorTestCase(unittest.TestCase):
    def test_detects_single_reflection(self) -> None:
        detector = ReflectionDetector()

        result = detector.detect("<div>XAIREF123</div>", "XAIREF123")

        self.assertTrue(result.reflected)
        self.assertEqual(result.occurrence_count, 1)
        self.assertEqual(result.offsets, [5])

    def test_detects_multiple_reflections(self) -> None:
        detector = ReflectionDetector()

        result = detector.detect(
            "<p>XAIREF123</p><span>XAIREF123</span>",
            "XAIREF123",
        )

        self.assertTrue(result.reflected)
        self.assertEqual(result.occurrence_count, 2)
        self.assertEqual(result.offsets, [3, 22])

    def test_returns_no_reflection_when_marker_absent(self) -> None:
        detector = ReflectionDetector()

        result = detector.detect("<div>no marker here</div>", "XAIREF123")

        self.assertFalse(result.reflected)
        self.assertEqual(result.occurrence_count, 0)
        self.assertEqual(result.offsets, [])

    def test_rejects_empty_marker(self) -> None:
        detector = ReflectionDetector()

        with self.assertRaises(ValueError):
            detector.detect("<div>anything</div>", "")


if __name__ == "__main__":
    unittest.main()
