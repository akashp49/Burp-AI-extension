import unittest

from app.analysis.waf.waf_fingerprinter import WafFingerprinter
from app.models.analysis import WafVendor


class WafFingerprinterTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.fingerprinter = WafFingerprinter()

    def test_detects_cloudflare_from_cf_ray(self) -> None:
        result = self.fingerprinter.fingerprint({"CF-Ray": "abc"})

        self.assertEqual(result.vendor, WafVendor.CLOUDFLARE)

    def test_detects_cloudflare_from_cookie(self) -> None:
        result = self.fingerprinter.fingerprint({"Set-Cookie": "__cf_bm=value"})

        self.assertEqual(result.vendor, WafVendor.CLOUDFLARE)

    def test_detects_akamai_from_cookie(self) -> None:
        result = self.fingerprinter.fingerprint({"Set-Cookie": "ak_bmsc=value"})

        self.assertEqual(result.vendor, WafVendor.AKAMAI)

    def test_detects_imperva_from_header(self) -> None:
        result = self.fingerprinter.fingerprint({"X-Iinfo": "10-123"})

        self.assertEqual(result.vendor, WafVendor.IMPERVA)

    def test_detects_aws_waf_from_header(self) -> None:
        result = self.fingerprinter.fingerprint({"X-Amzn-Waf-Action": "BLOCK"})

        self.assertEqual(result.vendor, WafVendor.AWS_WAF)

    def test_returns_unknown_without_signatures(self) -> None:
        result = self.fingerprinter.fingerprint({"Server": "nginx"})

        self.assertEqual(result.vendor, WafVendor.UNKNOWN)
        self.assertEqual(result.evidence, [])

    def test_header_names_are_case_insensitive(self) -> None:
        result = self.fingerprinter.fingerprint({"cf-ray": "abc"})

        self.assertEqual(result.vendor, WafVendor.CLOUDFLARE)


if __name__ == "__main__":
    unittest.main()

