import unittest
from unittest.mock import AsyncMock, patch

from fastapi.testclient import TestClient

from app.main import app
from app.api.suggest import payload_cache
from app.core.config import Settings
from app.models.analysis import (
    CspInfo,
    ReflectionContext,
    ReflectionEncoding,
    SecurityContext,
    WafVendor,
)
from app.models.suggestions import RequestContext
from app.services.gemini_client import GeminiClient
from app.services.json_extractor import extract_json_object
from app.services.payload_strategy import build_payload_strategy_hints
from app.services.prompt_builder import build_context_aware_xss_prompt
from app.services.suggestion_response_parser import parse_suggestion_response


client = TestClient(app)


class BackendTestCase(unittest.TestCase):
    def test_health_check(self) -> None:
        response = client.get("/health")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})

    def test_suggest_rejects_invalid_request(self) -> None:
        response = client.post("/suggest", json={"method": "GET"})

        self.assertEqual(response.status_code, 422)

    def test_suggest_returns_valid_payloads(self) -> None:
        payload_cache.clear()
        gemini_response = (
            '{"payloads":[{"payload":"<svg/onload=alert(1)>",'
            '"reason":"HTML reflection context","confidence":0.82}]}'
        )

        with patch(
            "app.api.suggest.GeminiClient.generate_json",
            new=AsyncMock(return_value=gemini_response),
        ):
            response = client.post(
                "/suggest",
                json={
                    "method": "GET",
                    "url": "https://example.test/search?q=test",
                    "headers": {"Content-Type": "text/html"},
                    "selected_text": "q=test",
                    "parameter_name": "q",
                    "content_type": "text/html",
                },
            )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.json(),
            {
                "payloads": [
                    {
                        "payload": "<svg/onload=alert(1)>",
                        "reason": "HTML reflection context",
                        "confidence": 0.82,
                    }
                ]
            },
        )

    def test_suggest_uses_payload_cache(self) -> None:
        payload_cache.clear()
        gemini_response = (
            '{"payloads":[{"payload":"<svg/onload=alert(1)>",'
            '"reason":"HTML reflection context","confidence":0.82}]}'
        )

        with patch(
            "app.api.suggest.GeminiClient.generate_json",
            new=AsyncMock(return_value=gemini_response),
        ) as mock_generate:
            request_json = {
                "method": "GET",
                "url": "https://example.test/search?q=test",
                "headers": {"Content-Type": "text/html"},
            }
            first_response = client.post("/suggest", json=request_json)
            second_response = client.post("/suggest", json=request_json)

        self.assertEqual(first_response.status_code, 200)
        self.assertEqual(second_response.status_code, 200)
        self.assertEqual(mock_generate.await_count, 1)

    def test_prompt_uses_compact_security_context(self) -> None:
        security_context = SecurityContext(
            reflection=True,
            reflection_count=1,
            context=ReflectionContext.HTML_ATTRIBUTE,
            encoding=ReflectionEncoding.NONE,
            waf=WafVendor.CLOUDFLARE,
            csp=CspInfo(
                present=True,
                unsafe_inline=False,
                nonce_present=True,
                strict_dynamic=False,
                raw_policy="script-src 'nonce-secret'",
            ),
        )

        prompt = build_context_aware_xss_prompt(security_context)

        self.assertIn("HTML_ATTRIBUTE", prompt)
        self.assertIn("cloudflare", prompt)
        self.assertIn("attr_breakout", prompt)
        self.assertIn("cloudflare_bypass", prompt)
        self.assertIn("csp_no_inline", prompt)
        self.assertNotIn("nonce-secret", prompt)
        self.assertNotIn("headers", prompt)
        self.assertLess(len(prompt), 380)

    def test_payload_strategy_hints_are_context_specific(self) -> None:
        security_context = SecurityContext(
            reflection=True,
            reflection_count=1,
            context=ReflectionContext.JS_STRING,
            encoding=ReflectionEncoding.PARTIAL_ESCAPE,
            waf=WafVendor.AWS_WAF,
            csp=CspInfo(
                present=True,
                unsafe_inline=False,
                nonce_present=False,
                strict_dynamic=True,
            ),
        )

        hints = build_payload_strategy_hints(security_context)

        self.assertEqual(
            hints,
            [
                "js_string_breakout",
                "quote_escape",
                "partial_escape_bypass",
                "aws_waf_bypass",
                "csp_no_inline",
            ],
        )

    def test_extracts_json_from_markdown_fence(self) -> None:
        raw_response = '```json\n{"payloads":[]}\n```'

        self.assertEqual(
            extract_json_object(raw_response),
            '{"payloads":[]}',
        )

    def test_parses_escaped_json_response(self) -> None:
        raw_response = (
            '{\\"payloads\\":[{\\"payload\\":\\"<script>alert(1)</script>\\",'
            '\\"reason\\":\\"Direct HTML context reflection.\\",'
            '\\"confidence\\":0.9}]}'
        )

        parsed_response = parse_suggestion_response(raw_response)

        self.assertEqual(
            parsed_response["payloads"][0]["payload"],
            "<script>alert(1)</script>",
        )

    def test_parses_double_escaped_json_response(self) -> None:
        raw_response = (
            '{\\\\\\"payloads\\\\\\":[{\\\\\\"payload\\\\\\":'
            '\\\\\\"<script>alert(1)</script>\\\\\\",'
            '\\\\\\"reason\\\\\\":\\\\\\"Direct HTML body reflection\\\\\\",'
            '\\\\\\"confidence\\\\\\":0.8}]}'
        )

        parsed_response = parse_suggestion_response(raw_response)

        self.assertEqual(
            parsed_response["payloads"][0]["reason"],
            "Direct HTML body reflection",
        )

    def test_recovers_quote_breakout_payload_from_escaped_json_response(self) -> None:
        raw_response = (
            '{\\"payloads\\":[{\\"payload\\":\\"\\\\\\">'
            '<script>alert(1)</script>\\",\\"reason\\":'
            '\\"Break out of HTML attribute and inject script.\\",'
            '\\"confidence\\":0.85}]}'
        )

        parsed_response = parse_suggestion_response(raw_response)

        self.assertEqual(
            parsed_response["payloads"][0]["payload"],
            '\"><script>alert(1)</script>',
        )

    def test_recovers_multiple_escaped_payload_objects(self) -> None:
        raw_response = (
            '{\\"payloads\\":[{\\"payload\\":\\"<script>alert(1)</script>\\",'
            '\\"reason\\":\\"Direct HTML injection\\",\\"confidence\\":0.8},'
            '{\\"payload\\":\\"<img src=x onerror=alert(1)>\\",'
            '\\"reason\\":\\"Image error handler\\",\\"confidence\\":0.75}]}'
        )

        parsed_response = parse_suggestion_response(raw_response)

        self.assertEqual(len(parsed_response["payloads"]), 2)
        self.assertEqual(
            parsed_response["payloads"][1]["payload"],
            "<img src=x onerror=alert(1)>",
        )

    def test_gemini_client_joins_split_text_parts(self) -> None:
        client = GeminiClient(
            Settings(
                gemini_api_key="test-key",
                gemini_model="gemini-2.5-flash",
            )
        )
        response_json = {
            "candidates": [
                {
                    "content": {
                        "parts": [
                            {"text": '{"payloads":[{"confidence":0.'},
                            {"text": '9,"payload":"x","reason":"r"}]}'},
                        ]
                    }
                }
            ]
        }

        self.assertEqual(
            client._extract_text(response_json),
            '{"payloads":[{"confidence":0.9,"payload":"x","reason":"r"}]}',
        )

    def test_gemini_request_limits_output_and_thinking(self) -> None:
        client = GeminiClient(
            Settings(
                gemini_api_key="test-key",
                gemini_model="gemini-2.5-flash",
            )
        )

        request_body = client._build_request_body("prompt")
        generation_config = request_body["generationConfig"]

        self.assertEqual(generation_config["maxOutputTokens"], 512)
        self.assertEqual(
            generation_config["thinkingConfig"],
            {"thinkingBudget": 0},
        )
        self.assertEqual(
            generation_config["responseSchema"]["properties"]["payloads"]["maxItems"],
            3,
        )

    def test_recovers_complete_objects_from_truncated_json_response(self) -> None:
        raw_response = (
            '{"payloads":[{"payload":"<script>alert(1)</script>",'
            '"reason":"Direct HTML script tag injection","confidence":0.85},'
            '{"payload":"<img src=x onerror=alert(1)>",'
            '"reason":"HTML tag with event handler","confidence":0.8},'
            '{"payload":"<svg/onload=alert(1)'
        )

        parsed_response = parse_suggestion_response(raw_response)

        self.assertEqual(len(parsed_response["payloads"]), 2)
        self.assertEqual(
            parsed_response["payloads"][0]["payload"],
            "<script>alert(1)</script>",
        )


if __name__ == "__main__":
    unittest.main()
