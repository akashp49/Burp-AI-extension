# Phase 2 Context Analysis Architecture

## Goal

Move deterministic security context analysis out of Gemini and into local backend code.
Gemini should only generate compact, context-aware payload mutations from a small
`SecurityContext` object.

## Data Flow

```text
Burp request/response context
        ↓
Reflection detection
        ↓
Reflection position mapping
        ↓
Context classification
        ↓
Encoding detection
        ↓
CSP extraction
        ↓
WAF fingerprinting
        ↓
SecurityContext
        ↓
Compact Gemini payload prompt
        ↓
Payload suggestions
```

## Backend Package Layout

```text
backend/app
├── analysis
│   ├── reflection
│   │   ├── detector.py
│   │   └── positions.py
│   ├── classification
│   │   └── context_classifier.py
│   ├── encoding
│   │   └── encoding_detector.py
│   ├── csp
│   │   └── csp_extractor.py
│   ├── waf
│   │   └── waf_fingerprinter.py
│   └── analyzer.py
├── models
│   ├── analysis.py
│   └── suggestions.py
└── services
    ├── prompt_builder.py
    └── gemini_client.py
```

Step 2 adds the first implementation module:

```text
backend/app/analysis/reflection/detector.py
backend/app/models/analysis.py
```

Step 3 adds a narrow reflection presence facade:

```text
backend/app/analysis/reflection/presence.py
```

Use this when orchestration only needs to know whether reflection exists. Use
`detector.py` when later steps need exact offsets.

Step 4 adds reflection position mapping:

```text
backend/app/analysis/reflection/positions.py
```

This turns raw offsets into bounded `before` and `after` snippets for later
context classification.

Step 5 adds deterministic context classification:

```text
backend/app/analysis/classification/context_classifier.py
```

Supported initial contexts:

- `HTML_BODY`
- `HTML_ATTRIBUTE`
- `SCRIPT_BLOCK`
- `JS_STRING`
- `URL_CONTEXT`
- `JSON_CONTEXT`

Step 6 adds deterministic encoding detection:

```text
backend/app/analysis/encoding/encoding_detector.py
```

Supported initial encodings:

- `NONE`
- `HTML_ENTITY`
- `URL_ENCODING`
- `UNICODE_ESCAPE`
- `PARTIAL_ESCAPE`

Step 7 adds CSP extraction:

```text
backend/app/analysis/csp/csp_extractor.py
```

Extracted fields:

- `present`
- `unsafe_inline`
- `nonce_present`
- `strict_dynamic`
- `script_src`

Step 8 adds WAF/CDN fingerprinting:

```text
backend/app/analysis/waf/waf_fingerprinter.py
```

Supported initial vendors:

- `cloudflare`
- `akamai`
- `imperva`
- `aws_waf`
- `unknown`

Step 9 adds the compact `SecurityContext` model and analyzer orchestrator:

```text
backend/app/analysis/analyzer.py
backend/app/models/analysis.py
```

The analyzer combines reflection, context, encoding, CSP, and WAF signals into
one compact object for later prompt generation.

Step 10 refactors the active Gemini prompt path:

```text
backend/app/services/prompt_builder.py
backend/app/api/suggest.py
backend/app/models/suggestions.py
```

`POST /suggest` now builds a `SecurityContext` first and sends Gemini only a
compact context prompt. Optional response fields were added to `RequestContext`
so later Burp extension steps can send response headers/body and a reflection
marker without changing the endpoint shape again.

Step 11 reduces Gemini token usage:

```text
backend/app/services/prompt_builder.py
backend/app/services/gemini_client.py
```

Changes:

- compact prompt keys (`ctx`, `enc`, `waf`)
- `maxOutputTokens` reduced to `512`
- `thinkingConfig.thinkingBudget` set to `0`
- response schema caps `payloads` with `maxItems: 3`
- temperature lowered to `0.1`

Step 12 adds an in-memory payload cache:

```text
backend/app/services/payload_cache.py
```

Cache key material:

- hostname
- reflection context
- encoding
- WAF vendor

The remaining module files above are planned implementation targets for later
steps.

## Component Responsibilities

### Reflection Detection

Detect whether a known marker, for example `XAIREF123`, appears in the HTTP
response.

Inputs:
- marker string
- response body

Outputs:
- `reflection: true | false`
- occurrence count
- raw character offsets

This module does not classify context. It only answers whether reflection exists
and where it appears.

### Reflection Position Mapping

Turn raw offsets into bounded snippets around each reflection.

Inputs:
- response body
- marker offsets
- configurable window size

Outputs:
- offset
- snippet before marker
- marker
- snippet after marker

This keeps later classifiers small and avoids sending full responses to Gemini.

### Context Classification

Classify each reflected marker into one of:

- `HTML_BODY`
- `HTML_ATTRIBUTE`
- `SCRIPT_BLOCK`
- `JS_STRING`
- `URL_CONTEXT`
- `JSON_CONTEXT`

Approach:
- Use deterministic local parsing.
- Prefer lightweight structural checks over broad regex-only classification.
- Use nearby syntax and parser-aware rules where possible.
- Keep the classifier conservative. If unsure, return `UNKNOWN` internally and
  map that to safer generic payload logic later.

### Encoding Detection

Detect how the marker or payload was transformed in the response.

Supported labels:
- `NONE`
- `HTML_ENTITY`
- `URL_ENCODING`
- `UNICODE_ESCAPE`
- `PARTIAL_ESCAPE`

Approach:
- Compare raw marker to known encoded variants.
- Detect mixed/partial escaping by checking which marker characters survived.
- Do not use AI.

### CSP Extraction

Extract CSP hints from response headers.

Fields:
- `script_src`
- `unsafe_inline`
- `nonce_present`
- `strict_dynamic`

Inputs:
- response headers

Outputs:
- compact CSP object used by prompt builder

### WAF Fingerprinting

Detect likely WAF/CDN from headers and cookies.

Supported labels:
- `cloudflare`
- `akamai`
- `imperva`
- `aws_waf`
- `unknown`

Signals:
- response headers
- response cookies
- server headers
- vendor-specific markers

This module should be confidence-light and deterministic. It should not claim a
WAF unless a known signature is present.

## SecurityContext Shape

Initial target model:

```json
{
  "reflection": true,
  "context": "HTML_ATTRIBUTE",
  "encoding": "HTML_ENTITY",
  "waf": "cloudflare",
  "csp": {
    "unsafe_inline": false,
    "nonce_present": true,
    "strict_dynamic": false,
    "script_src": ["self"]
  }
}
```

## Prompt Strategy

Current prompt sends too much context to Gemini. Phase 2 prompt should send only
compact context:

```json
{
  "context": "HTML_ATTRIBUTE",
  "encoding": "NONE",
  "waf": "cloudflare",
  "csp_inline_allowed": false
}
```

Instruction target:

```text
Generate 3 advanced XSS payloads.
JSON only.
No explanations.
```

Expected effect:
- prompt tokens below 300
- output tokens below 150
- no AI reflection analysis
- less generic payloads

## Integration Plan

Later steps will integrate the analyzer into `POST /suggest`:

1. Burp extension sends request context plus response body/headers when available.
2. Backend runs `SecurityContextAnalyzer`.
3. Backend builds compact Gemini prompt from `SecurityContext`.
4. Gemini returns payload suggestions only.

## Non-Goals

- No autonomous scanning.
- No request sending by the backend.
- No browser automation.
- No RAG, LangChain, vector databases, or agents.
- No AI-based reflection/context analysis.
