import com.pentest.aiburp.AiBurpPayloadAssistantExtension;
import com.pentest.aiburp.ExtensionMetadata;
import com.pentest.aiburp.api.BackendClient;
import com.pentest.aiburp.api.SuggestionResponseParser;
import com.pentest.aiburp.burp.PayloadSuggestionContextMenuProvider;
import com.pentest.aiburp.model.PayloadSuggestion;
import com.pentest.aiburp.ui.SuggestionTablePanel;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

class AiBurpPayloadAssistantExtensionTest {
    @Test
    void createsExtensionInstance() {
        AiBurpPayloadAssistantExtension extension =
                new AiBurpPayloadAssistantExtension();

        assertNotNull(extension);
    }

    @Test
    void exposesExtensionName() {
        assertNotNull(ExtensionMetadata.NAME);
    }

    @Test
    void exposesMenuItemText() {
        assertNotNull(PayloadSuggestionContextMenuProvider.MENU_ITEM_TEXT);
    }

    @Test
    void exposesDefaultBackendEndpoint() {
        assertNotNull(BackendClient.DEFAULT_SUGGEST_ENDPOINT);
    }

    @Test
    void parsesBackendSuggestionResponse() {
        SuggestionResponseParser parser = new SuggestionResponseParser();

        List<PayloadSuggestion> suggestions = parser.parse(
                "{\"payloads\":[{\"payload\":\"<svg/onload=alert(1)>\","
                        + "\"reason\":\"HTML reflection context\","
                        + "\"confidence\":0.82}]}"
        );

        assertEquals(1, suggestions.size());
        assertEquals("<svg/onload=alert(1)>", suggestions.get(0).payload());
    }

    @Test
    void createsSuggestionTablePanel() {
        SuggestionTablePanel panel = new SuggestionTablePanel();

        assertNotNull(panel);
    }
}
