# AI Burp Payload Assistant Extension

Minimal Burp Suite extension skeleton for the Phase 1 MVP.

## Build

```powershell
cd burp-extension
gradle clean build
```

The packaged extension JAR is created at:

```text
burp-extension/build/libs/ai-burp-payload-assistant-0.1.0.jar
```

Montoya API is declared as `compileOnly`, so it is not bundled into the JAR.
Burp provides Montoya at runtime.

The extension entry point class is:

```text
com.pentest.aiburp.AiBurpPayloadAssistantExtension
```

When loaded in Burp, the extension registers this name:

```text
AI Burp Payload Assistant
```

In Burp Repeater, the extension adds this right-click menu item:

```text
Suggest Payloads
```

When clicked, the extension extracts request context from Repeater:

- HTTP method
- URL
- non-sensitive headers
- request body
- selected request text, when available
- selected parameter name, when available
- content type

Then it sends the extracted context to the backend:

```text
POST http://127.0.0.1:8000/suggest
```

The extension parses backend responses with this shape:

```json
{
  "payloads": [
    {
      "payload": "<svg/onload=alert(1)>",
      "reason": "HTML reflection context",
      "confidence": 0.82
    }
  ]
}
```

Parsed suggestions are displayed in a Burp suite tab:

```text
AI Payloads
```

The tab contains a Swing table with:

- Payload
- Reason
- Confidence

The table uses wider payload columns, tooltips for long values, single-row
selection, sortable columns, and a status label showing how many suggestions are
currently displayed.

Error handling updates the same status label for:

- missing Repeater request context
- backend HTTP errors
- invalid backend JSON
- empty suggestion lists
- backend connection failures

To override the backend URL, set this environment variable before starting Burp:

```powershell
$env:AI_BURP_BACKEND_SUGGEST_URL = "http://127.0.0.1:8000/suggest"
```

## Requirements

- JDK 17+
- Gradle
- Burp Suite with Montoya API support
